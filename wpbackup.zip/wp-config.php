<?php // decoy wp-config
define('DB_NAME','x');
