<?php // wordpress decoy
echo 'wp';
